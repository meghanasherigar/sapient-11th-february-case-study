import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment3-child-four',
  templateUrl: './assignment3-child-four.component.html',
  styleUrls: ['./assignment3-child-four.component.scss']
})
export class Assignment3ChildFourComponent implements OnInit {
  @Input() startCountValue: any;
  @Input() pauseCountValue: any;
  constructor() { }

  ngOnInit(): void {
  }

}
