import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment3-child-one',
  templateUrl: './assignment3-child-one.component.html',
  styleUrls: ['./assignment3-child-one.component.scss']
})
export class Assignment3ChildOneComponent implements OnInit {
  @Input() intervalInfo: any;
  constructor() { }

  ngOnInit(): void {
  }

}
