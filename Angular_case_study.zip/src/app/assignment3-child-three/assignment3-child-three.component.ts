import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment3-child-three',
  templateUrl: './assignment3-child-three.component.html',
  styleUrls: ['./assignment3-child-three.component.scss']
})
export class Assignment3ChildThreeComponent implements OnInit {
  @Input()timeData:any;
  constructor() { }

  ngOnInit(): void {
  }

}
