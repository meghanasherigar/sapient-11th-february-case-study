import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-assignment3-child-two',
  templateUrl: './assignment3-child-two.component.html',
  styleUrls: ['./assignment3-child-two.component.scss']
})
export class Assignment3ChildTwoComponent implements OnInit {
  @Output() intervalInformation = new EventEmitter();
  inputValue: any = '';
  newYearCountdown: any;
  constructor(public datepipe: DatePipe) { }
  counter = 0;
  count = 0;
  startCount = 0;
  pauseCount = 0;
  ans = 0;
  pausedValue: Array<string> = [];
  timeArray: Array<string>
  tempInputValue: string;
  inputTargetValue: string;
  isBoolean: boolean;
  ngOnInit(): void {

  }
  change(event) {
    const text = event.target.value;
    this.inputTargetValue = text;
    this.isBoolean = true;
    this.count = 0;
    this.timeArray = [];
    this.startCount = 0;
    this.pauseCount = 0;
    this.pausedValue = [];
  }

  startStopTimer() {
    this.inputValue = this.inputTargetValue;
    if (this.inputValue != '') {
      this.count = this.count + 1;

      if (this.isBoolean) {
        if (this.count == 1) {
          this.ans = this.inputValue;
        }
      }

      if (this.count % 2 != 0) {
        this.counter = this.ans;
        this.startCount++;
        this.isBoolean = false;
        this.newYearCountdown = setInterval(() => {
          this.counter = this.counter - 1;
          if (this.counter >= 0) {
            this.intervalInformation.emit({
              counterValue: this.counter,
              startCount: this.startCount,
              pauseCount: this.pauseCount
            })
          }
        }, 50);
        if (this.counter >= 0) {
          this.timeArray.push(`Started at ${this.datepipe.transform((new Date), 'dd-MM-yyyy') + ' ' + this.datepipe.transform((new Date), 'mediumTime')}`);
          this.intervalInformation.emit({
            timeValue: this.timeArray
          })
        }

      }
      else {
        this.pauseCount++;
        this.ans = this.counter;
        clearTimeout(this.newYearCountdown);
        this.timeArray.push(`Stopped at ${this.datepipe.transform((new Date), 'dd-MM-yyyy') + ' ' + this.datepipe.transform((new Date), 'mediumTime')}`);
        this.pausedValue.push(`paused at ${this.counter}`);
        this.intervalInformation.emit({
          counterValue: this.counter,
          startCount: this.startCount,
          pauseCount: this.pauseCount,
          timeValue: this.timeArray
        })
      }
    }
  }
  clearTimer() {
    this.isBoolean = true;
    this.count = 0;
    this.timeArray = [];
    this.startCount = 0;
    this.pauseCount = 0;
    this.pausedValue = [];
    this.startStopTimer();
  }

}
