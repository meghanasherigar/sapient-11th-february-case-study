import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment3',
  templateUrl: './assignment3.component.html',
  styleUrls: ['./assignment3.component.scss']
})
export class Assignment3Component implements OnInit {
  intervalValue: any;
  startCount: any;
  pauseCount: any;
  timeValue: any;
  constructor() { }

  ngOnInit(): void {
  }
  intervalData(value: any) {
    this.intervalValue = value.counterValue;
    this.startCount = value.startCount;
    this.pauseCount = value.pauseCount;
    if (value.timeValue) {
      this.timeValue = value.timeValue;
    }
  }
}
