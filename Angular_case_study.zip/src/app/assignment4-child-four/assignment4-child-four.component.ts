import { Component, OnInit } from '@angular/core';
import { DataSharingService } from '../data-sharing.service';

@Component({
  selector: 'app-assignment4-child-four',
  templateUrl: './assignment4-child-four.component.html',
  styleUrls: ['./assignment4-child-four.component.scss']
})
export class Assignment4ChildFourComponent implements OnInit {
  startCountValue:number;
  pauseCountValue:number;
  constructor(private service: DataSharingService) { }

  ngOnInit(): void {
    this.service.timerSubject.subscribe((result: any) => {
      this.startCountValue = result.startCount;
      this.pauseCountValue = result.pauseCount;
    })
  }

}
