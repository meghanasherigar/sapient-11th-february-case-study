import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assignment4ChildOneComponent } from './assignment4-child-one.component';

describe('Assignment4ChildOneComponent', () => {
  let component: Assignment4ChildOneComponent;
  let fixture: ComponentFixture<Assignment4ChildOneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Assignment4ChildOneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Assignment4ChildOneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
