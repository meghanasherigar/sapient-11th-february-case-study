import { Component, OnInit } from '@angular/core';
import { DataSharingService } from '../data-sharing.service';

@Component({
  selector: 'app-assignment4-child-one',
  templateUrl: './assignment4-child-one.component.html',
  styleUrls: ['./assignment4-child-one.component.scss']
})
export class Assignment4ChildOneComponent implements OnInit {
  intervalInfo: Number;
  constructor(private service: DataSharingService) { }

  ngOnInit(): void {
    this.service.timerSubject.subscribe((result: any) => {
      this.intervalInfo = result.counterValue;
    })
  }

}
