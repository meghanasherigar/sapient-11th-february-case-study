import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assignment4ChildThreeComponent } from './assignment4-child-three.component';

describe('Assignment4ChildThreeComponent', () => {
  let component: Assignment4ChildThreeComponent;
  let fixture: ComponentFixture<Assignment4ChildThreeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Assignment4ChildThreeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Assignment4ChildThreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
