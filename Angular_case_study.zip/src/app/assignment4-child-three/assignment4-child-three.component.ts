import { Component, OnInit } from '@angular/core';
import { DataSharingService } from '../data-sharing.service';

@Component({
  selector: 'app-assignment4-child-three',
  templateUrl: './assignment4-child-three.component.html',
  styleUrls: ['./assignment4-child-three.component.scss']
})
export class Assignment4ChildThreeComponent implements OnInit {
  timeData: Array<any>;
  constructor(private service: DataSharingService) { }

  ngOnInit(): void {
    this.service.timerSubject.subscribe((result: any) => {
      this.timeData = result.timeValue;
    })
  }

}
