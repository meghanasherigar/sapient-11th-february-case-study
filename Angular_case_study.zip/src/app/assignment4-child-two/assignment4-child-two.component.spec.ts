import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assignment4ChildTwoComponent } from './assignment4-child-two.component';

describe('Assignment4ChildTwoComponent', () => {
  let component: Assignment4ChildTwoComponent;
  let fixture: ComponentFixture<Assignment4ChildTwoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Assignment4ChildTwoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Assignment4ChildTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
