import { Component, OnInit } from '@angular/core';

interface Student {
  name: string,
  class: number,
  section: string,
  sub1: number,
  sub2: number,
  sub3: number
}
@Component({
  selector: 'app-assignment5',
  templateUrl: './assignment5.component.html',
  styleUrls: ['./assignment5.component.scss']
})
export class Assignment5Component implements OnInit {
  studentData: Array<Student>;
  constructor() { }
  objectKeys = [];
  sortOrder = ['none', 'none', 'none', 'none', 'none', 'none'];
  studentCopyObject: Array<Student>;
  ngOnInit(): void {
    this.studentData = [
      {
        name: 'asfd',
        class: 2,
        section: 'D',
        sub1: 23,
        sub2: 54,
        sub3: 65

      },
      {
        name: 'asdf',
        class: 3,
        section: 'E',
        sub1: 23,
        sub2: 45,
        sub3: 67

      },
      {
        name: 'asdf',
        class: 3,
        section: 'F',
        sub1: 26,
        sub2: 34,
        sub3: 45

      },
      {
        name: 'asfd',
        class: 3,
        section: 'M  ',
        sub1: 16,
        sub2: 80,
        sub3: 43

      },

    ]

    for (var i = 0; i < this.studentData.length; i++) {
      for (var key in this.studentData[i]) {
        if (this.objectKeys.indexOf(key) === -1) {
          this.objectKeys.push(key);
        }
      }

    }
    this.studentCopyObject = JSON.parse(JSON.stringify(this.studentData));
  }

  sortData(item, i) {
    for (i = 0; i < this.sortOrder.length; i++) {
      switch (this.sortOrder[i]) {
        case 'none': this.studentData.sort((a, b) => {
          if (b[item] > a[item]) {
            return -1;
          }
          return 0;
        });
          this.sortOrder[i] = 'asec';
          break;
        case 'asec': this.studentData.sort((a, b) => {
          if (a[item] > b[item]) {
            return -1;
          }
          return 0;
        });
          this.sortOrder[i] = 'desc';
          break;
        case 'desc': this.studentData = this.studentCopyObject;
          this.sortOrder[i] = 'none';
          break;
        default: break;

      }
    }
  }

}
