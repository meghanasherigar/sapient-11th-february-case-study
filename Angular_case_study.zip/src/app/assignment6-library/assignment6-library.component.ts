import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-assignment6-library',
  templateUrl: './assignment6-library.component.html',
  styleUrls: ['./assignment6-library.component.scss']
})
export class Assignment6LibraryComponent implements OnInit {
  listItems: any = [];
  constructor(private router: Router) { }

  ngOnInit(): void {
    for (let i = 1; i <= 5; i++) {
      this.listItems.push(i);
    }
  }
  @HostListener('window:beforeunload', ['$event'])
  unloadHandler(event: Event) {
    window.scrollTo(0, 0);
  }
  onScroll() {
    const length = this.listItems.length;
    setTimeout(() => {
      const item = (' ').repeat(5).split('').map((s, i) => i + 1 + length);
      while (item.length) {
        this.listItems.push(item.shift());
      }
    }, 1500)
  }

  buttonClicked(i) {
    const ord = this.addOrdinalSuffix(i);
    alert(`Button in ${ord} div clicked`);
  }
  addOrdinalSuffix(int): any {
    const ones = +int % 10, tens = +int % 100 - ones;
    return int + ["th", "st", "nd", "rd"][tens === 10 || ones > 3 ? 0 : ones];
  }
  goTo() {
    this.router.navigate(['route6-without-library']);
  }

}
